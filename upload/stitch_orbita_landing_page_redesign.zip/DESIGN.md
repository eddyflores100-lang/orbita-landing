---
name: Obsidian Orbit
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#e29100'
  on-tertiary-container: '#523200'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
  surface-base: '#080C14'
  surface-raised: '#0F172A'
  surface-elevated: '#1E293B'
  mint-luminous: '#34D399'
  cyan-glow: '#22D3EE'
  amber-badge: '#FBBF24'
  border-subtle: rgba(255, 255, 255, 0.08)
  border-highlight: rgba(52, 211, 153, 0.25)
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 3.75rem
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: '1.45'
    letterSpacing: 0.005em
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0em
  label-stat:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system crafts an elite, high-precision atmosphere for algorithmic real estate valuation, portfolio risk assessment, and autonomous MLS transaction infrastructure. The aesthetic targets enterprise asset managers, proptech founders, and institutional brokers who demand the visual rigor of modern engineering platforms alongside the poise of high-capital finance.

The visual direction merges **Technical Minimalism** with **Hyper-Refined Glassmorphism**:
- **Atmosphere:** Deep midnight voids framed with razor-sharp 1px sub-surface borders, ambient luminous backdrops, and focused neon telemetry cues.
- **Demeanor:** Quiet confidence, computational authority, and zero noise. Density is balanced with deliberate typographic hierarchy and expansive breathing room.
- **Inspirations:** Modern developer-first enterprise tools (Linear, Vercel) blended with institutional financial terminals.

## Colors

The palette leverages an obsidian deep-space canvas to maximize the radiant potential of luminous emissive accents.

- **Primary (`#10B981` / `#34D399`):** Represents algorithmic health, verified liquidity, valuation growth, and forward action. Used for core interactive states, primary CTAs, positive telemetry deltas, and progress bars.
- **Secondary (`#06B6D4` / `#22D3EE`):** Signifies automated AI feeds, geospatial spatial telemetry, and computational pipelines. Used for interactive tabs, data visualization lines, and secondary action surfaces.
- **Tertiary (`#F59E0B` / `#FBBF24`):** Governs fiduciary compliance, escrow states, regulatory flags, and audited credibility markers.
- **Neutral (`#080C14` / `#0F172A` / `#1E293B`):** Multi-layered midnight slate surfaces providing seamless optical grounding, eliminating eye strain while framing high-density market feeds.
- **Contrast Guardrails:** All critical interface copy relies on `#FAFAFA` for titles and `#94A3B8` for secondary contextual labels, surpassing WCAG AAA legibility against the `#080C14` canvas.

## Typography

The typographic hierarchy implements a high-tech dual-engine system:
- **Headlines & Interface Body (`Plus Jakarta Sans`):** Offers immaculate geometry, clear geometric apertures, and contemporary polish across high-density SaaS views. Tracking tightens progressively as size ascends to retain density and physical authority.
- **Data, Metadata & Telemetry (`JetBrains Mono`):** Applied strictly to MLS identifiers, geospatial coordinates, currency valuations, capitalization rates, API paths, and micro badges. The fixed tabular figures eliminate jitter during live streaming mutations.

## Layout & Spacing

A structured 12-column dynamic fluid grid architecture underpins the platform:
- **Desktop (1200px+):** 12 columns with `1.5rem` gutters and minimum `3rem` canvas margins. Side utility panels and live telemetry drawers snap to 4-column and 8-column splits.
- **Tablet (768px - 1199px):** 8 columns with `1.25rem` gutters, converting analytical sidecars into collapsable bottom sheets or swappable tabs.
- **Mobile (< 768px):** 4 columns with `1rem` gutters and `1.25rem` outer margins. High-density property matrices collapse gracefully into structured vertical cards with inline horizontal metric scrolls.
- **Vertical Spacing Cadence:** Built around a 4px/8px modular scale. Component internal padding stays tight (`space-sm` to `space-md`) to enforce data-density, while macro section separation commands `space-xl` to avoid cognitive overload.

## Elevation & Depth

Visual hierarchy uses physical optical layering rather than traditional muddy drop shadows:

- **Level 0 (Canvas Base):** Infinite midnight slate `#080C14` with ambient, non-uniform radial gradient blooms (emerald and cyan at 4–8% opacity with 120px blur) placed strategically behind key modules.
- **Level 1 (Panels & Shells):** `#0F172A` at 70% opacity backed by `backdrop-filter: blur(16px)` and sealed with a crisp 1px stroke of `rgba(255, 255, 255, 0.07)`.
- **Level 2 (Interactive Cards & Floating Overlays):** `#1E293B` at 85% opacity, `backdrop-filter: blur(24px)`, bounded by `rgba(255, 255, 255, 0.12)`. Casts an ambient shadow: `0 12px 32px -4px rgba(0, 0, 0, 0.6)`.
- **Level 3 (Focused & Hover States):** Surface outline lifts to `rgba(52, 211, 153, 0.35)` with a targeted soft exterior radiance: `0 0 20px -2px rgba(16, 185, 129, 0.22)`.

## Shapes

The interface balances precision engineering with sleek ergonomic geometry:
- Default radius is calibrated to `0.5rem` (8px) for buttons, inputs, filter chips, and inner container cells.
- Large panels, dashboard cards, and modal sheets scale to `1rem` (16px) for an architectural, contained frame.
- Badges, status pills, and toggle indicators adopt fully rounded pill radii (`9999px`) to immediately separate interactive operational indicators from static data blocks.

## Components

### Buttons & CTAs
- **Primary Action:** Solid `#10B981` background, `#080C14` bold typography, fine inset top highlight `inset 0 1px 0 rgba(255,255,255,0.3)`. Hover triggers a smooth transform with a targeted neon cast: `box-shadow: 0 0 20px rgba(16, 185, 129, 0.4)`.
- **Secondary / Ghost:** Translucent background (`rgba(255, 255, 255, 0.04)`), 1px border `rgba(255, 255, 255, 0.1)`, hover shifts to `rgba(255, 255, 255, 0.08)` and border color to `#22D3EE`.
- **Destructive:** Dark crimson base with `rgba(239, 68, 68, 0.15)` fill, `1px solid rgba(239, 68, 68, 0.3)`.

### Chips & Badges
- **Monospace Micro-Badges:** Uppercase JetBrains Mono, `0.6875rem`, letter-spacing `0.06em`, pill-radius. 
- **Variants:**
  - *Active / Yield:* Emerald tint background (`rgba(16, 185, 129, 0.12)`), text `#34D399`, pulsing 6px dot indicator.
  - *AI Stream / Sync:* Cyan tint background (`rgba(6, 182, 212, 0.12)`), text `#22D3EE`.
  - *Compliance / Escrow:* Amber tint background (`rgba(245, 158, 11, 0.12)`), text `#FBBF24`.

### Interactive Data Tables
- Header cells: Uppercase monospace `0.75rem`, color `#64748B`, bottom border `1px solid rgba(255, 255, 255, 0.06)`.
- Row styling: Alternating subtle row-striping disabled; instead, transparent rows activate to `rgba(255, 255, 255, 0.03)` with a solid `#10B981` 2px vertical left-accent indicator on hover.
- Tabular figures applied to all price models, square footage, cap rates, and transaction IDs.

### Input Fields & Selectors
- Default container: Filled `#080C14` inset into `#0F172A` cards, border `1px solid rgba(255, 255, 255, 0.08)`.
- Focused state: Border brightens to `#10B981` with soft outer glow `0 0 0 3px rgba(16, 185, 129, 0.15)`. Text sits in clean `#FAFAFA` with placeholder copy muted at `#475569`.

### Comparison Tabs & Switchers
- Encased in an outer pill rail of `#080C14` with a subtle inner border.
- Active segment glides with a glass pill (`#1E293B` with `border: 1px solid rgba(255,255,255,0.12)`), while non-active items display subdued slate text that brightens upon mouse collision.

### Cards & Analytical Widgets
- Multi-layer glass composite with 1px border (`rgba(255, 255, 255, 0.08)`).
- Top edge incorporates an internal 1px gradient sheen running from transparent to `rgba(255, 255, 255, 0.15)` to transparent, simulating refined top-lit chamfered glass.